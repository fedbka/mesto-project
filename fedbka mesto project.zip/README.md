# Выполненный учебный проект курса "Веб+" Яндекс.Практикума: Mesto

## Описание

Учебный проект по адаптивной верстке и Javascript "Место". Реализован в рамках выполнения задачи третьего спринта курса Web-разработчик+ на Яндекс.Практикуме.

## Что было использовано и изучено
* Работа с проектами в Figma
* Использование grid-layout и flex
* Использование calc для расчетов значений CSS-свойств
* Javascript для реализации интерактива

## Ссылка на результат проекта

* [Путешествия по России](https://fedbka.github.io/mesto-project/index.html)
## Ссылки на макеты

* [Ссылка на макет в Figma - спринт 2](https://www.figma.com/file/2cn9N9jSkmxD84oJik7xL7/JavaScript.-Sprint-4?node-id=0%3A1)
* [Ссылка на макет в Figma - спринт 3](https://www.figma.com/file/bjyvbKKJN2naO0ucURl2Z0/JavaScript.-Sprint-5?node-id=0%3A1)
